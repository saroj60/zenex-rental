import React from 'react';
import SearchWidget from './SearchWidget';
import { ArrowRight, Play, Star } from 'lucide-react';

const Hero = () => {
  return (
    <>
      <section className="relative h-[800px] w-full flex flex-col pt-32 pb-48 px-4 md:px-8">
        <div className="absolute inset-0 z-0">
          <img
            alt="NepalDrive Fleet in the Himalayas"
            className="w-full h-full object-cover"
            src="/hero-custom.jpg"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
        </div>
        
        <div className="relative z-10 w-full max-w-7xl mx-auto flex flex-col justify-center flex-1">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md text-white px-4 py-1.5 rounded-full text-xs font-bold mb-6 border border-white/20 shadow-sm">
              <Star className="text-[#EA580C] fill-current" size={14}/> #1 Car Rental Service in Nepal
            </span>
            <h2 className="text-5xl md:text-7xl font-extrabold text-white leading-[1.1] mb-6 drop-shadow-lg">
              Explore Nepal<br/>Your Way
            </h2>
            <p className="text-lg md:text-xl text-white/90 mb-8 max-w-lg leading-relaxed drop-shadow-md font-medium">
              Rent cars, SUVs, and 4x4 adventure vehicles across Nepal with instant booking and trusted local service.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <button className="w-full sm:w-auto bg-[#EA580C] text-white px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-3 hover:bg-[#d04b08] transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5">
                Find Your Vehicle
                <div className="bg-white text-[#EA580C] rounded-full p-1">
                  <ArrowRight size={16} strokeWidth={3} />
                </div>
              </button>
              <button className="w-full sm:w-auto text-white px-6 py-4 rounded-xl font-bold flex items-center justify-center gap-3 hover:bg-white/10 transition-colors">
                <div className="w-10 h-10 border-2 border-white/60 rounded-full flex items-center justify-center">
                  <Play size={16} className="ml-1" fill="currentColor" />
                </div>
                View Packages
              </button>
            </div>
          </div>
        </div>

        {/* Floating Search Widget */}
        <div className="absolute left-0 right-0 bottom-0 translate-y-1/2 z-20 px-4 md:px-8 flex justify-center">
          <div className="w-full max-w-7xl">
            <SearchWidget />
          </div>
        </div>
      </section>
      
      {/* Spacer for the floating widget */}
      <div className="h-[400px] md:h-[300px]"></div>
    </>
  );
};

export default Hero;
