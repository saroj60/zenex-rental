import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Calendar, Car, Search, HeadphonesIcon, ShieldCheck, Zap, Shield, Users, Map, Navigation } from 'lucide-react';

const SearchWidget = () => {
  const [pickupLocation, setPickupLocation] = useState('Kathmandu, Nepal');
  const [dropoffLocation, setDropoffLocation] = useState('Kathmandu, Nepal');
  const [pickupDate, setPickupDate] = useState('');
  const [returnDate, setReturnDate] = useState('');
  const [vehicleType, setVehicleType] = useState('SUV / 4x4');
  const [isSearching, setIsSearching] = useState(false);
  
  const navigate = useNavigate();

  const handleSearch = () => {
    setIsSearching(true);
    setTimeout(() => {
      setIsSearching(false);
      const params = new URLSearchParams({
        pickup: pickupLocation,
        dropoff: dropoffLocation,
        start: pickupDate,
        end: returnDate,
        type: vehicleType
      });
      navigate(`/vehicles?${params.toString()}`);
    }, 400);
  };

  return (
    <div className="bg-white/40 backdrop-blur-xl border border-white/40 rounded-3xl p-6 md:p-8 shadow-2xl shadow-black/10">
      
      {/* Top Search Bar */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-0 divide-y md:divide-y-0 md:divide-x divide-gray-300/50 bg-[#F4F6F8]/80 backdrop-blur-md rounded-2xl p-2 mb-6">
        <div className="p-3">
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1 mb-1">
            <MapPin size={14} className="text-gray-400" /> Pickup Location
          </label>
          <select 
            value={pickupLocation}
            onChange={(e) => setPickupLocation(e.target.value)}
            className="w-full bg-transparent border-none text-gray-900 font-bold focus:ring-0 appearance-none outline-none cursor-pointer text-sm"
          >
            <option value="Kathmandu, Nepal">Kathmandu, Nepal</option>
            <option value="Pokhara, Nepal">Pokhara, Nepal</option>
            <option value="Chitwan, Nepal">Chitwan, Nepal</option>
            <option value="Lumbini, Nepal">Lumbini, Nepal</option>
            <option value="Mustang, Nepal">Mustang, Nepal</option>
          </select>
        </div>
        
        <div className="p-3">
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1 mb-1">
            <MapPin size={14} className="text-gray-400" /> Drop-off Location
          </label>
          <select 
            value={dropoffLocation}
            onChange={(e) => setDropoffLocation(e.target.value)}
            className="w-full bg-transparent border-none text-gray-900 font-bold focus:ring-0 appearance-none outline-none cursor-pointer text-sm"
          >
            <option value="Kathmandu, Nepal">Kathmandu, Nepal</option>
            <option value="Pokhara, Nepal">Pokhara, Nepal</option>
            <option value="Chitwan, Nepal">Chitwan, Nepal</option>
            <option value="Lumbini, Nepal">Lumbini, Nepal</option>
            <option value="Mustang, Nepal">Mustang, Nepal</option>
          </select>
        </div>
        
        <div className="p-3">
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1 mb-1">
            <Calendar size={14} className="text-gray-400" /> Pickup Date
          </label>
          <input 
            type="date"
            value={pickupDate}
            onChange={(e) => setPickupDate(e.target.value)}
            className="w-full bg-transparent border-none text-gray-900 font-bold focus:ring-0 outline-none cursor-pointer text-sm"
          />
        </div>
        
        <div className="p-3">
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1 mb-1">
            <Calendar size={14} className="text-gray-400" /> Return Date
          </label>
          <input 
            type="date"
            value={returnDate}
            onChange={(e) => setReturnDate(e.target.value)}
            className="w-full bg-transparent border-none text-gray-900 font-bold focus:ring-0 outline-none cursor-pointer text-sm"
          />
        </div>
        
        <div className="p-3">
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1 mb-1">
            <Car size={14} className="text-gray-400" /> Vehicle Type
          </label>
          <select 
            value={vehicleType}
            onChange={(e) => setVehicleType(e.target.value)}
            className="w-full bg-transparent border-none text-gray-900 font-bold focus:ring-0 appearance-none outline-none cursor-pointer text-sm"
          >
            <option value="SUV / 4x4">SUV / 4x4</option>
            <option value="Economy">Economy</option>
            <option value="Premium">Premium</option>
            <option value="Van / Micro">Van / Micro</option>
          </select>
        </div>
        
        <div className="p-2 flex">
          <button
            onClick={handleSearch}
            className={`w-full bg-[#1e3a8a] text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-all ${
              isSearching ? 'scale-95 opacity-90' : 'hover:bg-[#152c6e] shadow-md hover:shadow-lg'
            }`}
          >
            <Search size={18} /> Search Vehicles
          </button>
        </div>
      </div>

      {/* Middle Features */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-4 mb-6 border-b border-gray-400/20">
        <div className="flex items-start gap-3">
          <HeadphonesIcon className="text-[#1e3a8a] mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">24/7 Support</h4>
            <p className="text-xs text-gray-600 mt-0.5">We're here anytime</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <ShieldCheck className="text-[#1e3a8a] mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Verified Drivers</h4>
            <p className="text-xs text-gray-600 mt-0.5">Experienced & trusted</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Zap className="text-[#1e3a8a] mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Instant Booking</h4>
            <p className="text-xs text-gray-600 mt-0.5">Book in just a few clicks</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Shield className="text-[#1e3a8a] mt-1" size={24} />
          <div>
            <h4 className="font-bold text-gray-900 text-sm">Fully Insured Vehicles</h4>
            <p className="text-xs text-gray-600 mt-0.5">Your safety, our priority</p>
          </div>
        </div>
      </div>

      {/* Bottom Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-white/60 backdrop-blur-md rounded-2xl p-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-[#1e3a8a] rounded-2xl flex items-center justify-center text-white shadow-lg">
            <Car size={24} />
          </div>
          <div>
            <h3 className="font-bold text-xl text-gray-900">500+</h3>
            <h4 className="font-bold text-sm text-gray-700">Vehicles</h4>
            <p className="text-xs text-gray-500">Wide range of cars</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-[#2D6A4F] rounded-2xl flex items-center justify-center text-white shadow-lg">
            <Users size={24} />
          </div>
          <div>
            <h3 className="font-bold text-xl text-gray-900">10,000+</h3>
            <h4 className="font-bold text-sm text-gray-700">Happy Travelers</h4>
            <p className="text-xs text-gray-500">Trusted by thousands</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-[#EA580C] rounded-2xl flex items-center justify-center text-white shadow-lg">
            <Map size={24} />
          </div>
          <div>
            <h3 className="font-bold text-xl text-gray-900">25+</h3>
            <h4 className="font-bold text-sm text-gray-700">Destinations</h4>
            <p className="text-xs text-gray-500">Across beautiful Nepal</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchWidget;
